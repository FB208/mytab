import { ensureInit, readAll, addFolder, renameFolder, deleteFolder, addSubfolder, renameSubfolder, deleteSubfolder, addBookmark, renameBookmark, deleteBookmark, buildFaviconUrl, updateBookmarkMono, updateBookmarkFavicon, updateBookmark, reorderBookmarksRelative } from './storage.js';

let state = {
  selectedFolderId: null,
  selectedSubId: null,
  keyword: ''
};

await ensureInit();
await bootstrap();

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'data:changed') {
    render();
  }
});

async function bootstrap() {
  bindEvents();
  await render();
}

function bindEvents() {
  document.getElementById('btn-settings').addEventListener('click', () => {
    if (chrome.runtime.openOptionsPage) chrome.runtime.openOptionsPage();
  });

  document.getElementById('btn-add-folder').addEventListener('click', async () => {
    const name = await textPrompt({ title: '新建一级文件夹', placeholder: '文件夹名称' });
    if (!name) return;
    const folder = await addFolder(name);
    state.selectedFolderId = folder.id;
    state.selectedSubId = null;
    render();
  });

  document.getElementById('btn-add-subfolder').addEventListener('click', async () => {
    if (!state.selectedFolderId) return toast('请先选择一个一级文件夹');
    const name = await textPrompt({ title: '新建二级文件夹', placeholder: '二级文件夹名称' });
    if (!name) return;
    await addSubfolder(state.selectedFolderId, name);
    render();
  });

  document.getElementById('btn-add-bookmark').addEventListener('click', async () => {
    if (!state.selectedFolderId) return alert('请先选择一个一级文件夹');
    openBookmarkModal({ mode: 'add' });
  });

  document.getElementById('search').addEventListener('input', (e) => {
    state.keyword = e.target.value.trim();
    renderBookmarkGrid();
  });
}

async function render() {
  const { data } = await readAll();
  const bg = document.getElementById('bg');
  bg.style.backgroundImage = data.backgroundImage ? `url(${data.backgroundImage})` : '';
  renderFolderList();
  renderSubfolders();
  renderBookmarkGrid();
}

async function renderFolderList() {
  const { data } = await readAll();
  const list = document.getElementById('folder-list');
  list.innerHTML = '';
  const tpl = document.getElementById('tpl-folder-item');

  if (!state.selectedFolderId && data.folders[0]) state.selectedFolderId = data.folders[0].id;

  data.folders.forEach(folder => {
    const el = tpl.content.firstElementChild.cloneNode(true);
    el.dataset.id = folder.id;
    el.querySelector('.icon').textContent = folder.icon || '📁';
    el.querySelector('.name').textContent = folder.name;
    if (folder.id === state.selectedFolderId) el.classList.add('active');
    el.addEventListener('click', () => {
      state.selectedFolderId = folder.id;
      state.selectedSubId = null;
      document.getElementById('current-folder-name').textContent = folder.name;
      renderFolderList();
      renderSubfolders();
      renderBookmarkGrid();
    });
    el.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      openContextMenu(e.clientX, e.clientY, [
        { label: '重命名', onClick: async () => { const name = await textPrompt({ title: '重命名', placeholder: folder.name, value: folder.name }); if (name) { await renameFolder(folder.id, name); render(); } } },
        { label: '删除', onClick: async () => { const ok = await confirmPrompt('确认删除该文件夹及其内容？'); if (ok) { await deleteFolder(folder.id); if (state.selectedFolderId === folder.id) { state.selectedFolderId = null; state.selectedSubId = null; } render(); } } }
      ]);
    });
    list.appendChild(el);
  });

  const current = data.folders.find(f => f.id === state.selectedFolderId);
  document.getElementById('current-folder-name').textContent = current?.name || '欢迎 👋';
}

async function renderSubfolders() {
  const { data } = await readAll();
  const wrap = document.getElementById('subfolder-list');
  wrap.innerHTML = '';
  if (!state.selectedFolderId) return;
  const folder = data.folders.find(f => f.id === state.selectedFolderId);
  (folder?.subfolders || []).forEach(sub => {
    const el = document.getElementById('tpl-subfolder-item').content.firstElementChild.cloneNode(true);
    el.dataset.id = sub.id;
    el.querySelector('.name').textContent = sub.name;
    el.addEventListener('click', () => { state.selectedSubId = sub.id; renderBookmarkGrid(); });
    el.querySelector('.rename').addEventListener('click', async (e) => {
      e.stopPropagation();
      const name = await textPrompt({ title: '重命名', placeholder: sub.name, value: sub.name });
      if (name) { await renameSubfolder(folder.id, sub.id, name); renderSubfolders(); }
    });
    el.querySelector('.delete').addEventListener('click', async (e) => {
      e.stopPropagation();
      const ok = await confirmPrompt('删除该二级文件夹？');
      if (ok) { await deleteSubfolder(folder.id, sub.id); if (state.selectedSubId === sub.id) state.selectedSubId = null; renderSubfolders(); renderBookmarkGrid(); }
    });
    wrap.appendChild(el);
  });
}

async function renderBookmarkGrid() {
  const { data } = await readAll();
  const grid = document.getElementById('bookmark-grid');
  grid.innerHTML = '';
  if (!state.selectedFolderId) return;
  const folder = data.folders.find(f => f.id === state.selectedFolderId);
  const container = state.selectedSubId ? (folder?.subfolders || []).find(s => s.id === state.selectedSubId) : folder;
  const list = (container?.bookmarks || []).filter(bm => matchKeyword(bm, state.keyword));

  const tpl = document.getElementById('tpl-bookmark-card');
  list.forEach(bm => {
    const el = tpl.content.firstElementChild.cloneNode(true);
    el.dataset.id = bm.id;
    el.title = bm.name || bm.url;
    const titleEl = el.querySelector('.title');
    if (titleEl) titleEl.textContent = bm.name || bm.url;
    // 拖拽属性
    el.setAttribute('draggable', 'true');
    el.addEventListener('dragstart', (ev) => {
      ev.dataTransfer.setData('text/plain', bm.id);
      ev.dataTransfer.effectAllowed = 'move';
    });
    el.addEventListener('dragover', (ev) => {
      ev.preventDefault();
      ev.dataTransfer.dropEffect = 'move';
    });
    el.addEventListener('drop', async (ev) => {
      ev.preventDefault();
      const sourceId = ev.dataTransfer.getData('text/plain');
      const targetId = bm.id;
      if (!sourceId || sourceId === targetId) return;
      await reorderBookmarksRelative({ folderId: folder.id, subId: state.selectedSubId, sourceId, targetId });
      renderBookmarkGrid();
    });
    const img = el.querySelector('.favicon');
    const mono = el.querySelector('.mono-icon');
    if (bm.iconType === 'favicon' && bm.iconUrl) {
      img.src = bm.iconUrl;
      img.style.display = 'block';
      mono.style.display = 'none';
      img.onerror = async () => {
        // 自动降级为单色图标并持久化
        const letter = (bm.name || bm.url || 'W')[0] || 'W';
        const color = pickColorFromString(letter);
        await updateBookmarkMono({ folderId: folder.id, subId: state.selectedSubId, bookmarkId: bm.id, letter, color });
        renderBookmarkGrid();
      };
    } else if (bm.mono) {
      mono.style.display = 'grid';
      mono.style.background = bm.mono.color;
      mono.querySelector('.letter').textContent = (bm.mono.letter || '?').toUpperCase();
      img.style.display = 'none';
    }
    el.addEventListener('click', () => window.open(bm.url, '_blank'));
    el.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      openContextMenu(e.clientX, e.clientY, [
        { label: '编辑', onClick: () => openBookmarkModal({ mode: 'edit', bookmark: { ...bm }, folderId: folder.id, subId: state.selectedSubId }) },
        { label: '删除', onClick: async () => { const ok = await confirmPrompt('删除该书签？'); if (ok) { await deleteBookmark({ folderId: folder.id, subId: state.selectedSubId, bookmarkId: bm.id }); renderBookmarkGrid(); } } }
      ]);
    });
    grid.appendChild(el);
  });
}

function matchKeyword(bm, kw) {
  if (!kw) return true;
  const k = kw.toLowerCase();
  return (bm.name || '').toLowerCase().includes(k) || (bm.url || '').toLowerCase().includes(k);
}

function pickColorFromString(s) {
  const colors = ['#7c5cff', '#f59e0b', '#10b981', '#ef4444', '#06b6d4', '#8b5cf6', '#22c55e'];
  const idx = Math.abs(hashCode(s)) % colors.length;
  return colors[idx];
}

function hashCode(str) {
  let h = 0; for (let i = 0; i < str.length; i++) { h = Math.imul(31, h) + str.charCodeAt(i) | 0; } return h;
}

// 轻量 toast
function toast(text, duration = 1600) {
  const t = document.createElement('div');
  t.textContent = text;
  Object.assign(t.style, { position: 'fixed', right: '20px', bottom: '20px', background: 'rgba(15,23,42,0.9)', color: '#fff', padding: '10px 14px', borderRadius: '10px', zIndex: 9999, boxShadow: '0 6px 20px rgba(0,0,0,0.25)', fontSize: '13px' });
  document.body.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; }, duration - 300);
  setTimeout(() => t.remove(), duration);
}

// 文本输入弹窗
async function textPrompt({ title = '输入', message = '', placeholder = '', value = '' } = {}) {
  const root = document.getElementById('text-modal');
  const backdrop = document.getElementById('modal-backdrop');
  const titleEl = document.getElementById('tm-title');
  const msgEl = document.getElementById('tm-message');
  const input = document.getElementById('tm-input');
  const btnClose = document.getElementById('tm-close');
  const btnCancel = document.getElementById('tm-cancel');
  const btnSave = document.getElementById('tm-save');
  return new Promise((resolve) => {
    titleEl.textContent = title;
    msgEl.textContent = message;
    msgEl.classList.toggle('hidden', !message);
    input.placeholder = placeholder;
    input.value = value;
    root.classList.remove('hidden');
    backdrop.classList.remove('hidden');
    input.focus();
    const cleanup = (val) => {
      root.classList.add('hidden');
      backdrop.classList.add('hidden');
      btnClose.onclick = btnCancel.onclick = btnSave.onclick = null;
      resolve(val);
    };
    btnClose.onclick = () => cleanup('');
    btnCancel.onclick = () => cleanup('');
    btnSave.onclick = () => cleanup(input.value.trim());
  });
}

// 确认弹窗（复用文本弹窗的外壳）
async function confirmPrompt(message) {
  const root = document.getElementById('text-modal');
  const backdrop = document.getElementById('modal-backdrop');
  const titleEl = document.getElementById('tm-title');
  const msgEl = document.getElementById('tm-message');
  const input = document.getElementById('tm-input');
  const btnClose = document.getElementById('tm-close');
  const btnCancel = document.getElementById('tm-cancel');
  const btnSave = document.getElementById('tm-save');
  return new Promise((resolve) => {
    titleEl.textContent = '确认';
    msgEl.textContent = message;
    msgEl.classList.remove('hidden');
    input.value = '';
    input.classList.add('hidden');
    root.classList.remove('hidden');
    backdrop.classList.remove('hidden');
    const cleanup = (val) => {
      root.classList.add('hidden');
      backdrop.classList.add('hidden');
      input.classList.remove('hidden');
      btnClose.onclick = btnCancel.onclick = btnSave.onclick = null;
      resolve(val);
    };
    btnClose.onclick = () => cleanup(false);
    btnCancel.onclick = () => cleanup(false);
    btnSave.onclick = () => cleanup(true);
  });
}

// 自定义右键菜单
const ctxMenu = {
  root: document.getElementById('context-menu'),
  list: document.getElementById('context-menu-list')
};

function openContextMenu(x, y, items) {
  ctxMenu.list.innerHTML = '';
  items.forEach(it => {
    const li = document.createElement('li');
    li.textContent = it.label;
    li.addEventListener('click', () => { hideContextMenu(); it.onClick?.(); });
    ctxMenu.list.appendChild(li);
  });
  ctxMenu.root.style.left = x + 'px';
  ctxMenu.root.style.top = y + 'px';
  ctxMenu.root.classList.remove('hidden');
  const onDoc = () => hideContextMenu();
  setTimeout(() => document.addEventListener('click', onDoc, { once: true }), 0);
}

function hideContextMenu() {
  ctxMenu.root.classList.add('hidden');
}
// Modal 逻辑
const modal = {
  backdrop: document.getElementById('modal-backdrop'),
  root: document.getElementById('bookmark-modal'),
  title: document.getElementById('modal-title'),
  close: document.getElementById('modal-close'),
  cancel: document.getElementById('modal-cancel'),
  save: document.getElementById('modal-save'),
  url: document.getElementById('bm-url'),
  name: document.getElementById('bm-name'),
  favUrl: document.getElementById('bm-favicon'),
  fetchFav: document.getElementById('bm-fetch-fav'),
  favCandidatesWrap: document.getElementById('row-fav-candidates'),
  favCandidates: document.getElementById('bm-fav-candidates'),
  letter: document.getElementById('bm-letter'),
  color: document.getElementById('bm-color'),
  rowFav: document.getElementById('row-favicon'),
  rowMono: document.getElementById('row-mono'),
  previewFav: document.getElementById('preview-fav'),
  previewMono: document.getElementById('preview-mono'),
  modeRadios: () => [...document.querySelectorAll('input[name="icon-mode"]')]
};

let modalCtx = { mode: 'add', bookmarkId: null, folderId: null, subId: null };

function openBookmarkModal({ mode, bookmark = null, folderId = null, subId = null }) {
  modalCtx = { mode, bookmarkId: bookmark?.id || null, folderId: folderId || state.selectedFolderId, subId: subId || state.selectedSubId };
  modal.title.textContent = mode === 'add' ? '添加书签' : '编辑书签';
  modal.url.value = bookmark?.url || '';
  modal.name.value = bookmark?.name || '';
  const iconType = bookmark?.iconType || 'favicon';
  modal.modeRadios().forEach(r => r.checked = r.value === iconType);
  modal.favUrl.value = bookmark?.iconUrl || '';
  modal.letter.value = bookmark?.mono?.letter || ((bookmark?.name || bookmark?.url || 'W')[0] || 'W');
  modal.color.value = bookmark?.mono?.color || '#7c5cff';
  applyIconMode(iconType);
  refreshPreview();
  clearFavCandidates();
  showModal(true);
}

function showModal(show) {
  modal.backdrop.classList.toggle('hidden', !show);
  modal.root.classList.toggle('hidden', !show);
}

modal.close?.addEventListener('click', () => showModal(false));
modal.cancel?.addEventListener('click', () => showModal(false));

modal.modeRadios().forEach(r => r.addEventListener('change', () => {
  applyIconMode(getIconMode());
  refreshPreview();
}));

[modal.url, modal.favUrl, modal.letter, modal.color].forEach(el => el?.addEventListener('input', refreshPreview));

modal.save?.addEventListener('click', async () => {
  const folderId = modalCtx.folderId;
  const subId = modalCtx.subId;
  const url = modal.url.value.trim();
  if (!url) { alert('请输入网址'); return; }
  const name = modal.name.value.trim() || undefined;
  const mode = getIconMode();
  if (modalCtx.mode === 'add') {
    if (mode === 'favicon') {
      const iconUrl = modal.favUrl.value.trim() || buildFaviconUrl(url);
      await addBookmark({ folderId, subId, url, name, iconUrl, mono: null });
    } else {
      const letter = (modal.letter.value || (name || url || 'W')[0] || 'W').toUpperCase();
      const color = modal.color.value || pickColorFromString(letter);
      await addBookmark({ folderId, subId, url, name, iconUrl: '', mono: { letter, color } });
    }
  } else {
    const bookmarkId = modalCtx.bookmarkId;
    if (mode === 'favicon') {
      const iconUrl = modal.favUrl.value.trim();
      await updateBookmark({ folderId, subId, bookmarkId, url, name, iconType: 'favicon', iconUrl: iconUrl || undefined });
    } else {
      const letter = (modal.letter.value || (name || url || 'W')[0] || 'W').toUpperCase();
      const color = modal.color.value || '#7c5cff';
      await updateBookmark({ folderId, subId, bookmarkId, url, name, iconType: 'mono', mono: { letter, color } });
    }
  }
  showModal(false);
  renderBookmarkGrid();
});

modal.fetchFav?.addEventListener('click', async () => {
  const url = modal.url.value.trim();
  if (!url) { alert('请先填写网址'); return; }
  try {
    const candidates = await collectFavicons(url);
    renderFavCandidates(candidates);
  } catch (e) {
    alert('获取失败');
  }
});

function getIconMode() { return modal.modeRadios().find(r => r.checked)?.value || 'favicon'; }

function applyIconMode(mode) {
  const isFav = mode === 'favicon';
  modal.rowFav.classList.toggle('hidden', !isFav);
  modal.rowMono.classList.toggle('hidden', isFav);
}

function refreshPreview() {
  const mode = getIconMode();
  if (mode === 'favicon') {
    modal.previewFav.style.display = 'block';
    modal.previewMono.style.display = 'none';
    const url = modal.url.value.trim();
    const fav = modal.favUrl.value.trim() || (url ? buildFaviconUrl(url) : '');
    modal.previewFav.src = fav;
  } else {
    modal.previewFav.style.display = 'none';
    modal.previewMono.style.display = 'grid';
    const letter = (modal.letter.value || (modal.name.value || modal.url.value || 'W')[0] || 'W').toUpperCase();
    modal.previewMono.querySelector('.letter').textContent = letter;
    modal.previewMono.style.background = modal.color.value || '#7c5cff';
  }
}

function clearFavCandidates() {
  if (!modal.favCandidates) return;
  modal.favCandidates.innerHTML = '';
  modal.favCandidatesWrap?.classList.add('hidden');
}

function renderFavCandidates(urls) {
  clearFavCandidates();
  if (!urls || urls.length === 0) return;
  modal.favCandidatesWrap?.classList.remove('hidden');
  urls.forEach(u => {
    const item = document.createElement('div');
    item.className = 'fav-candidate';
    const img = document.createElement('img');
    img.src = u;
    item.appendChild(img);
    item.title = u;
    item.addEventListener('click', () => {
      modal.favUrl.value = u;
      refreshPreview();
    });
    modal.favCandidates.appendChild(item);
  });
}

async function collectFavicons(pageUrl) {
  // 尝试常见路径 + 获取 HTML 内的 <link rel="icon">
  const u = new URL(pageUrl);
  const common = [
    `${u.origin}/favicon.ico`,
    `${u.origin}/apple-touch-icon.png`,
    `${u.origin}/apple-touch-icon-precomposed.png`
  ];
  let linkIcons = [];
  try {
    const html = await fetch(pageUrl, { method: 'GET' }).then(r => r.text());
    linkIcons = extractIconsFromHtml(html, u.origin);
  } catch (e) {}
  const all = [...new Set([...linkIcons, ...common])];
  // 过滤不可访问的
  const checks = await Promise.all(all.map(async (href) => {
    try {
      const res = await fetch(href, { method: 'HEAD' });
      if (res.ok && res.headers.get('content-type')?.includes('image')) return href;
    } catch (e) {}
    return null;
  }));
  return checks.filter(Boolean);
}

function extractIconsFromHtml(html, base) {
  const results = [];
  const re = /<link[^>]+rel=["']([^"']*)["'][^>]*>/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    const tag = m[0];
    const rel = (m[1] || '').toLowerCase();
    if (!/(icon|shortcut icon|apple-touch-icon)/.test(rel)) continue;
    const hrefMatch = /href=["']([^"']+)["']/i.exec(tag);
    if (!hrefMatch) continue;
    const href = hrefMatch[1];
    const url = href.startsWith('http') ? href : (href.startsWith('/') ? (base + href) : (base + '/' + href));
    results.push(url);
  }
  return results;
}
